<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\OtpMail;
use App\Models\User;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    /**
     * Logout the user
     */
    protected function loggedOut(Request $request)
    {
        return redirect()->route('login');
    }

    /**
     * Validate credentials
     */
    protected function credentials(Request $request)
    {
        return [
            'email'    => request()->email,
            'password' => request()->password,
            'status'   => 1
        ];
    }

    /**
     * Authentication
     *
     * @param Request $request
     * @param Object $user
     * @return void
     */
    protected function authenticated(Request $request, $user)
    {
        $this->sendOtp($user);
        // Check if OTP is required
        if ($user->otp) {
            return view('auth.enter-otp');
        }

        // Redirect after regular authentication
        return redirect(RouteServiceProvider::HOME);
    }

    /**
     * Send OTP
     *
     * @param Object $user
     * @return void
     */
    public function sendOtp($user)
    {
        $user = User::where(['email' => $user->email])->first(); // Get the authenticated user
        if ($user) {
            $otp = $this->generateOTP();    // Generate OTP

            // Save OTP to the user's record
            $user->update(['otp' => $otp]);

            // Send OTP via email
            Mail::to($user->email)->send(new OtpMail($otp));

            return response()->json(['message' => 'OTP sent successfully']);
        }

        return back()->withErrors(['email' => 'User not found']);
    }

    /**
     * Generate OTP
     *
     * @param integer $length
     * @return void
     */
    function generateOTP($length = 6)
    {
        return rand(pow(10, $length - 1), pow(10, $length) - 1);
    }

    /**
     * Verify OTP
     *
     * @param Request $request
     * @return void
     */
    public function verifyOTP(Request $request)
    {
        dd($request->all());
        // $this->validate($request, [
        //     'otp' => 'required|string|max:6',
        // ]);
        

        // $user = auth()->user();

        // if ($user->otp == $request->otp) {
        //     $user->update(['otp' => null]);
        //     return redirect(RouteServiceProvider::HOME);
        // }

        // return back()->withErrors(['otp' => 'Invalid OTP']);
    }
}
